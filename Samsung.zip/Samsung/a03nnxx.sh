mhpc=/data/adb/modules/MagiskProps/system.prop

rm -rf $mhpc

mk="Samsung Galaxy A03" id=TP1A.220624.014 br=samsung acak="$(head -16 /dev/urandom | tr -cd 'A-Z' | cut -c -6)$(head -16 /dev/urandom | tr -cd '1-9' | cut -c -2)" mnf=samsung dev=a03 nm=a03nnxx mod="SM-A035F" inc=A035FXXS5CWK1 rc=13 host="21DK7920$(head -16 /dev/urandom | tr -cd '0-6' | cut -c -3)" fp=$br/$nm/$dev:$rc/$id/$inc:user/release-keys des="$nm-user $rc $id $inc release-keys" dis=$id.$inc

echo "ro.build.fingerprint=$fp" >> $mhpc
echo "ro.bootimage.build.fingerprint=$fp" >> $mhpc
echo "ro.system.build.fingerprint=$fp" >> $mhpc
echo "ro.vendor.build.fingerprint=$fp" >> $mhpc
echo "ro.product.build.fingerprint=$fp" >> $mhpc
echo "ro.odm.build.fingerprint=$fp" >> $mhpc
echo "ro.system_ext.build.fingerprint=$fp" >> $mhpc
echo "" >> $mhpc
echo "ro.build.description=$des" >> $mhpc
echo "" >> $mhpc
echo "ro.build.display.id=$dis" >> $mhpc
echo "" >> $mhpc
echo "ro.build.id=$id" >> $mhpc
echo "ro.system.build.id=$id" >> $mhpc
echo "ro.vendor.build.id=$id" >> $mhpc
echo "ro.product.build.id=$id" >> $mhpc
echo "ro.odm.build.id=$id" >> $mhpc
echo "ro.system_ext.build.id=$id" >> $mhpc
echo "" >> $mhpc
echo "ro.build.version.incremental=$inc" >> $mhpc
echo "ro.system.build.version.incremental=$inc" >> $mhpc
echo "ro.vendor.build.version.incremental=$inc" >> $mhpc
echo "ro.product.build.version.incremental=$inc" >> $mhpc
echo "ro.odm.build.version.incremental=$inc" >> $mhpc
echo "ro.system_ext.build.version.incremental=$inc" >> $mhpc
echo "" >> $mhpc
echo "ro.build.version.release=$rc" >> $mhpc
echo "ro.system.build.version.release=$rc" >> $mhpc
echo "ro.vendor.build.version.release=$rc" >> $mhpc
echo "ro.product.build.version.release=$rc" >> $mhpc
echo "ro.odm.build.version.release=$rc" >> $mhpc
echo "ro.system_ext.build.version.release=$rc" >> $mhpc
echo "" >> $mhpc
echo "ro.product.brand=$acak" >> $mhpc
echo "ro.product.system.brand=$acak" >> $mhpc
echo "ro.product.vendor.brand=$acak" >> $mhpc
echo "ro.product.product.brand=$acak" >> $mhpc
echo "ro.product.odm.brand=$acak" >> $mhpc
echo "ro.product.system_ext.brand=$acak" >> $mhpc
echo "" >> $mhpc
echo "ro.product.device=$dev" >> $mhpc
echo "ro.product.system.device=$dev" >> $mhpc
echo "ro.product.vendor.device=$dev" >> $mhpc
echo "ro.product.product.device=$dev" >> $mhpc
echo "ro.product.odm.device=$dev" >> $mhpc
echo "ro.product.system_ext.device=$dev" >> $mhpc
echo "" >> $mhpc
echo "ro.product.manufacturer=$mnf" >> $mhpc
echo "ro.product.system.manufacturer=$mnf" >> $mhpc
echo "ro.product.vendor.manufacturer=$mnf" >> $mhpc
echo "ro.product.product.manufacturer=$mnf" >> $mhpc
echo "ro.product.odm.manufacturer=$mnf" >> $mhpc
echo "ro.product.system_ext.manufacturer=$mnf" >> $mhpc
echo "" >> $mhpc
echo "ro.product.model=$mod" >> $mhpc
echo "ro.product.system.model=$mod" >> $mhpc
echo "ro.product.vendor.model=$mod" >> $mhpc
echo "ro.product.product.model=$mod" >> $mhpc
echo "ro.product.odm.model=$mod" >> $mhpc
echo "ro.product.system_ext.model=$mod" >> $mhpc
echo "" >> $mhpc
echo "ro.product.name=$nm" >> $mhpc
echo "ro.product.system.name=$nm" >> $mhpc
echo "ro.product.vendor.name=$nm" >> $mhpc
echo "ro.product.product.name=$nm" >> $mhpc
echo "ro.product.odm.name=$nm" >> $mhpc
echo "ro.product.system_ext.name=$nm" >> $mhpc
echo "" >> $mhpc
echo "ro.build.product=$dev" >> $mhpc
echo "ro.build.host=$host" >> $mhpc
echo "ro.build.flavor=$nm-user" >> $mhpc

BT=$(grep -n bluetooth_name /data/system/users/0/settings_secure.xml | grep -o 'value=".*"*' | cut -d '"' -f2)
DV=$(grep -n device_name /data/system/users/0/settings_global.xml | grep -o 'value=".*"*' | cut -d '"' -f2)
ID=$(grep -n database_creation_buildid /data/system/users/0/settings_global.xml | grep -o 'value=".*"*' | cut -d '"' -f2)

sed -i '/Name =/d' /data/misc/bluedroid/bt_config.conf
echo "Name = $mk" >> /data/misc/bluedroid/bt_config.conf

sed -i "s/$BT/$mk/g" /data/system/users/0/settings_secure.xml

sed -i "s/$DV/$mk/g" /data/system/users/0/settings_global.xml

sed -i "s/$ID/$id/g" /data/system/users/0/settings_global.xml

settings delete secure android_id
settings delete secure bluetooth_address

pm clear com.whatsapp
pm clear com.whatsapp.w4b
pm clear com.google.android.gms
pm clear com.google.android.gsf
pm clear com.android.vending
pm clear com.android.webview
pm clear com.android.chrome
pm clear com.gojek.gopay
pm clear com.tokopedia.tkpd
pm clear com.lazada.android
pm clear com.shopee.id

rm -rf /data/data/com.lazada.android
rm -rf /storage/emulated/0/.mixplorer
rm -rf /storage/emulated/0/Android
rm -rf /storage/emulated/0/data
rm -rf /storage/emulated/0/MT2
rm -rf /storage/emulated/0/Fox
rm -rf /storage/emulated/0/Movies
rm -rf /storage/emulated/0/Music
rm -rf /storage/emulated/0/Pictures
rm /data/system/users/0/settings_ssaid.xml
rm -rf /data/system/users/0/*.fallback
rm -rf /storage/emulated/0/WhatsApp\ Business
rm -rf /storage/emulated/0/WhatsApp

sleep 1

reboot